#include <stdio.h>
void main (){
        int x = 42;
        if(x < 23)
                printf("TOTO\n");
        else
                printf("TITI\n");
}
